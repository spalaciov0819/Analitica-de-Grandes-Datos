INSERT INTO 'tipo_documento' ('CdTipoDocIdCliente','NombreDocumento') VALUES ('1','CEDULA EXTRANJERIA');
INSERT INTO 'tipo_documento' ('CdTipoDocIdCliente','NombreDocumento') VALUES ('2','CEDULA CIUDADANIA');
INSERT INTO 'tipo_documento' ('CdTipoDocIdCliente','NombreDocumento') VALUES ('3','PASAPORTE');
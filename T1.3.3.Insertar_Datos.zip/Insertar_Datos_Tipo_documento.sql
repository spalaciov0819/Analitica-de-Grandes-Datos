INSERT INTO 'TIPO_DOCUMENTO' ('CdTipoDocIdCliente','NombreDocumento') VALUES ('1','CEDULA EXTRANJERIA');
INSERT INTO 'TIPO_DOCUMENTO' ('CdTipoDocIdCliente','NombreDocumento') VALUES ('2','CEDULA CIUDADANIA');
INSERT INTO 'TIPO_DOCUMENTO' ('CdTipoDocIdCliente','NombreDocumento') VALUES ('3','PASAPORTE');
INSERT INTO 'CANAL' ('CdCanal','Canal') VALUES ('1','Fisico');
INSERT INTO 'CANAL' ('CdCanal','Canal') VALUES ('2','Domicilios');
INSERT INTO 'CANAL' ('CdCanal','Canal') VALUES ('3','Online');
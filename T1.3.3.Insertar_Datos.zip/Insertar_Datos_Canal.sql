INSERT INTO 'canal' ('CdCanal','canal') VALUES ('1','Fisico');
INSERT INTO 'canal' ('CdCanal','canal') VALUES ('2','Domicilios');
INSERT INTO 'canal' ('CdCanal','canal') VALUES ('3','Online');